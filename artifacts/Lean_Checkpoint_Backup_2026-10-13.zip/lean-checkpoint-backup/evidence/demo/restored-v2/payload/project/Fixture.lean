-- Second synthetic fixture version; not compiled.
theorem fixture : 3 = 3 := rfl
