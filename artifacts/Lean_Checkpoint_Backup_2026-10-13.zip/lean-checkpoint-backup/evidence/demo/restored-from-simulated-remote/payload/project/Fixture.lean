-- Synthetic backup fixture; not compiled in these tests.
theorem fixture : 2 + 2 = 4 := by decide
