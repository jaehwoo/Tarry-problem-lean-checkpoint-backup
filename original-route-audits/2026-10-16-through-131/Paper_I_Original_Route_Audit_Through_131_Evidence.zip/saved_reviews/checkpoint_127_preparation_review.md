# Checkpoint 127: original preparation argument, focused review

Review scope: the one-variable step in the authoritative main manuscript at I929–954, its centerline application at I1263, and the immediately relevant downstream uses. Read `AGENTS.md` and `VERIFICATION_POLICY.md` first. The manuscript was not edited. This is a mathematical/source review, not an additional Lean execution claim. The root audit records the actual new declarations and their compilation separately.

## Pre-strategy obstruction and boundary checks

The previously open obligations in checkpoint 126 were retained: a formatted Lipschitz centerline does not yet supply smooth regular pieces, uniformly formatted higher derivatives, a common good set, or an interval of comparable length. None of these conclusions may be included in a new external-citation hypothesis.

The following cases were checked before recommending the finite-difference application.

* **Order zero.** The formula involving `1/j` is used only for `j >= 1`. At `j = 0`, `|f| <= B` itself gives the desired bound whenever the common constant is at least one. The strict signed superlevel sets at threshold `C B` are empty when `B >= 0` and `C >= 1`.
* **Zero amplitude.** On a nondegenerate interval, `|f| <= 0` forces `f = 0`; all positive derivatives vanish at interior points where the smoothness hypothesis applies. Cancellation of `B` is therefore permitted only after splitting the case `B = 0`. A finite-difference contradiction with a strictly positive derivative threshold also works without cancellation.
* **Zero length and empty intervals.** There is no positive-length retained interval when `L = 0`. Do not assign the usual real-analytic meaning to `L^(-j)` in that case merely because Lean's inverse is total. A length-zero interval can have empty good interior and zero exceptional measure, but it cannot imply the later strip-area conclusion. The geometric application needs its already intended positive longitudinal length; a point-image path does not provide that premise.
* **Open components.** A superlevel component can be open and need not contain its endpoints. Place the stencil strictly inside it; do not assert smoothness across its boundary. For a bounded component `(l,r)` of length `ell > 0`, the nodes `l + ell/4 + i*ell/(2*j)`, `0 <= i <= j`, lie strictly inside `(l,r)` and span its middle half.
* **Derivative existence.** The project already distinguishes `HasDerivAt`/actual derivative loci from the default value of Lean's `deriv` at nondifferentiable points (`GraphDerivativeLoci.lean`). This distinction must persist for higher derivatives and exceptional regularity points.
* **Uniformity.** The signed-component count must precede the coefficients, interval endpoints, amplitude, and threshold. The derivative order, prescribed finite list, format, and exceptional fraction may determine constants. A fixed-format hypothesis must not be replaced by pointwise finiteness for each individual scalar. The finite-list size belongs to the specified auxiliary data in I621–623/I929–930.
* **Centerline translation.** A constant function `h(q)=H` on `[0,1]` is 0-Lipschitz for arbitrary `H`; graph format does not bound its absolute height by the interval length. Thus the same raw `h` in checkpoint 126 cannot acquire a uniform order-zero amplitude estimate without explicit normalization. For positive derivatives, apply the amplitude estimate to `h-h(q0)` and retain the original strip with its offset. This is an application bridge, not a license to redefine the geometric witness.

Executed diagnostic command: `python3 - <<'PY' ... PY` using exact `fractions.Fraction` arithmetic and `math.comb`, for orders 1 through 12. It checked the degree-j monomial finite-difference identity, the absolute binomial coefficient sum, strict interior membership of the middle-half nodes, and their half-length span: **48 assertions passed; exit code 0**. These finite arithmetic checks are not proofs of the general analytic result. The reproducible script is below.

```python
from fractions import Fraction as F
from math import comb, factorial
for j in range(1, 13):
    a, h = F(-7, 3), F(5, 11)
    s = sum((-1)**(j-i)*comb(j, i)*(a+i*h)**j for i in range(j+1))
    assert s == factorial(j)*h**j
    assert sum(abs((-1)**(j-i)*comb(j, i)) for i in range(j+1)) == 2**j
    l, r = F(-9, 7), F(13, 5)
    ell = r-l
    pts = [l+ell/F(4)+i*ell/F(2*j) for i in range(j+1)]
    assert all(l < x < r for x in pts)
    assert pts[-1]-pts[0] == ell/2
```

## Exact accepted citation and proposed input boundary

Primary source: Carl de Boor, *Divided differences*, Surveys in Approximation Theory 1 (2005), 46–69, [publisher PDF](https://surveys-in-approximation-theory.com/papers/2/2.pdf), the manuscript bibliography entry at I3367. Equation (41), printed p.60/PDF p.15, expresses the divided difference at distinct nodes as `sum f(x_i)/w'(x_i)`, where `w=product (X-x_i)`. Equation (44), printed p.61/PDF p.16, identifies `j!` times that divided difference with a value of the j-th derivative. The preceding Proposition 43 argument uses repeated Rolle interlacing. Equation (52), printed p.64/PDF p.19, is the Genocchi–Hermite integral representation; it is an available alternative, unnecessary for this batch's mean-value specialization.

For `j > 0`, `h > 0`, and a real scalar `f` of class `C^j` on `[a,a+j*h]`, the appropriate named input is precisely

\[
\exists \xi\in(a,a+jh),\qquad h^j f^{(j)}(\xi)
 = \sum_{i=0}^{j}(-1)^{j-i}\binom ji f(a+ih).
\]

This is a specialization of (41) and (44), not an assumed superlevel-length bound. Indeed the distinct equispaced nodes satisfy

\[
w'(a+ih)=h^j(-1)^{j-i}i!(j-i)!.
\]

Substituting this expression in (41) and multiplying (44) by `h^j` gives the displayed formula. Strict interior placement of the mean-value point follows from repeated Rolle with distinct nodes. `ContDiffOn` on the closed interval is sufficient; the ambient iterated derivative is evaluated only at the interior point. No analytic behavior outside that closed interval is asserted or needed.

Source acceptance: applicable published input accepted under `VERIFICATION_POLICY.md`. Exact source match: checked for this equispaced specialization. Independent Lean proof of the publication: not claimed or required by this policy. No global axiom or inhabitant should be introduced. The explicit input must remain visible in the types of dependent theorems.

A bounded correction search on the publisher domain and the [author's publication list](https://pages.cs.wisc.edu/~deboor/deboorreadme.html) found no identified correction affecting these formulas. This is not an exhaustive errata certification.

## Project calculation to be verified in Lean

The arithmetic and application below are project work, not part of the assumed citation. For either sign `sigma in {1,-1}`, suppose `sigma*f^(j)(x) >= M` throughout the stencil interval, `|f(x)| <= B`, and `B >= 0`. The absolute coefficient sum is `sum binom(j,i) = 2^j`, so the cited equality gives

\[
M h^j\le 2^j B.
\]

For the middle-half stencil above, `h=ell/(2j)`, and hence

\[
M\ell^j\le (4j)^j B.\tag{127.1}
\]

The constant depends only on `j`; no dependence on the location, coefficients, component, or amplitude enters. With `B>0`, `L>0`, `M=C B L^{-j}`, (127.1) implies `ell <= 4j C^(-1/j)L`. A fixed upper bound `K_j` on signed interval counts then gives the small exceptional-length estimate after choosing `C` using the fixed orders, list size, and exceptional fraction. The new citation contract must not assume these counting, scaling, summation, or common-good-set conclusions.

The original manuscript uses the same divided-difference argument. Choosing middle-half nodes changes only the permitted order-dependent constant and makes the endpoint issue explicit. It is not a replacement analytic proof. There is no need to switch to a Hardt endpoint-path proof. Inherited scalar counting may still use Hardt; this review makes no wholly Hardt-free claim.

## Correspondence and remaining obligations

| Manuscript location | Reviewed content | Exact remaining project work |
|---|---|---|
| I929–930 | Specified finite lists, absolute/relative/characteristic preparation | Retain the selected coordinates, scales, amplitudes, and finite list in each application. |
| I933–950 | One-variable signed-superlevel/divided-difference argument underlying preparation | Build the interval cover, sum lengths with a coefficient-uniform count, combine the finite derivative list, and handle `j=0`, zero amplitude and exceptional regularity points explicitly. |
| I952 | Horizontal preparation, vertical component trimming and Fubini | Still unformalized here; an interval estimate alone does not prove the two-variable common-good-set conclusion. |
| I954 | Monotone flux parameter | Prove derivative-expression algebraicity in the original parameter, preservation of interval counts, and apply the estimate in the actual flux interval. Do not assume the primitive is algebraic. |
| I1263 | Preparation of the same selected centerline | Supply smooth regular intervals and uniform fixed-order derivative formats, a valid amplitude normalization, the common good set, bounded component count, and one interval of comparable longitudinal length. |
| I1261, I1263–1266 | Area, packing, endpoints and measurable assignment | Remain independent obligations; no positive-area or complete planar-strip theorem follows from the interval helper alone. |

Current code correspondence: `FormattedSpanningPlanarGraphArc` in `OriginalRouteFormattedPlanarArcs.lean` retains the same `h`, the 1-Lipschitz estimate, graph correctness, onto witness, and uniform graph format. `BufferedFormattedPlanarArcs.lean` adds containment of every longitudinal restriction. Neither structure asserts the needed preparation. `PublishedFormatDerivativeSignCuts.lean` and `GraphDerivativeLoci.lean` provide relevant prior infrastructure, but first-derivative sign cuts alone are not all fixed-order derivative format bounds.

## Findings and scope

No fatal flaw or typo was established in this scoped review. The assumed smoothness, fixed format and fixed finite lists are hypotheses of the manuscript, not defects. The main blockers above are missing project application/infrastructure and implementation work, not unavailable execution or failure of the cited theorem.

The raw-height obstruction is recorded without declaring the manuscript false. Surrounding uses support translated coordinates: I1309 states Gauss-variable translation covariance, I1323 uses relative endpoints at the unchanged original frame, and I2729 uses centerline jets of order at least two. The preparation application must expose its normalization and preserve the original geometric map. I1250–1254, I1272 and I3217 do not explicitly specify the order-zero convention; that notation/application question remains open rather than silently choosing a stronger global statement. If a future formal target includes `j=0` in unshifted absolute coordinates, it would be an overstrong target, and the smallest coherent clarification would be to state the local translated coordinate convention at I1250–1254 and propagate it to I1272/I3217 while retaining offsets in actual strip maps. No manuscript repair is made or asserted necessary in this batch.

Verification remains incomplete. In particular, a verified signed-superlevel interval estimate does not certify the complete preparation lemma, the same-centerline application, or the main theorem.
