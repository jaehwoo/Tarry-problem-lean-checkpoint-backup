# Checkpoint 127: correspondence and scope review

The completed batch contains 43 new theorem proofs, five definitions, and one explicit published-result contract in eight modules. All 49 declarations were checked in the pinned Lean 4.19.0/mathlib environment. The contract is a proposition-valued input, not a theorem proved here. Full manuscript verification remains incomplete, including verification relative to the accepted published inputs.

## New mathematical result

The one-variable preparation argument at I950 is now implemented for a finite list of functions whose graphs have bounded polynomial-sign format. For fixed format bounds s,D, order N, finite index type, and epsilon>0, one constant C>=1 is chosen before every graph coefficient, function, amplitude and endpoint. If a<b, each function is C^N on (a,b), its graph has the supplied format there, and |f_i|<=B_i there, the theorem constructs a measurable G subset (a,b) with

    volume((a,b) minus G) <= epsilon*(b-a),
    |f_i^(n)(x)| <= C*B_i/(b-a)^n  for x in G and n<=N.

The final theorem is `PaperI.published_bounded_format_finite_list_preparation`. Its actual compiled type appears below. Amplitude nonnegativity is derived at the midpoint, rather than added to that final theorem. Empty lists, N=0, B_i=0 and every epsilon>0 are retained. Positive interval length is explicit; no retained positive interval is claimed for zero length.

## Original argument and accepted inputs

The proof follows the manuscript's signed-superlevel and divided-difference argument. De Boor's equations (41) and (44) give the equispaced mean-value identity for C^j real functions, j>0 and positive spacing. The new named input is `PublishedEquispacedDividedDifferenceMeanValue`. Its sole field states that identity and supplies an interior evaluation point. It assumes no preparation, component-count, exceptional-measure or interval-length conclusion. The source and specialization are reviewed in `checkpoint_127_preparation_review.md`; no independent Lean proof or inhabitant of this contract is supplied.

The other inputs are the already accepted `PublishedFiniteConnectedCover`, `PublishedSemialgebraicHardtTriviality`, and `PublishedRealSemialgebraicity`. Their source policy and contracts are retained. An axiom audit does not discharge these explicit parameters. The finite-list result is a verified implication using these accepted inputs under `VERIFICATION_POLICY.md`.

The local calculation is Lean-checked: the binomial coefficient sum gives M*h^j <= 2^j*B; a closed stencil in the middle half of an open component gives M*ell^j <= (4j)^j*B. The strict version handles zero amplitude without division by B. Actual open connected components are represented as bounded open intervals, their lengths are summed, both signs are combined, and finitely many function/order conditions are intersected. All constants precede coefficients, endpoints, amplitudes and functions.

Middle-half nodes make the original argument's endpoint detail explicit and change only the permitted order-dependent constant. This is not a replacement analytic proof. Both inherited endpoint-path constructions and original analytic/sign subdivision remain unchanged. Scalar component counting still uses Hardt; no wholly Hardt-free result is claimed. The alternative Hardt endpoint proof does not certify the original intermediate argument, and neither is relabeled by this batch.

## Statement correspondence

| Location | Lean unit | Verified scope |
| --- | --- | --- |
| I950, interval-component assertion | IteratedDerivativeLoci; OriginalPreparationSuperlevels | Actual local derivative graphs through fixed order, continuity, open signed superlevels and coefficient-uniform component bounds |
| I950, divided-difference application | PreparationDividedDifferences | Mean-value input instantiated on interior nodes; homogeneous component-length bound, including strict and zero-amplitude cases |
| I950, summing component lengths | OpenComponentIntervals; OriginalOneVariablePreparation | Actual bounded open components, signed and absolute exceptional-measure estimates |
| I929-930/I950, common finite list | OriginalPreparationFiniteList | One common measurable good set and one uniform constant for bounded-format semialgebraic graphs |
| I951, discarding short intervals | PreparationIntervalSelection | Finite-union budgets and retained original interval from supplied positive good mass/count; no actual centerline good interval supplied yet |
| I1250-1263, centerline amplitudes | CenteredPreparationAmplitude | Lipschitz centering gives amplitude at most interval length, preserves smoothness and positive derivatives, and leaves the geometric centerline unchanged |

## Obstructions and boundary tests before implementation

The checkpoint126 buffer and degenerate-path obstructions were retained without changing those proofs. Before the new strategy, 243 exact rational polynomial finite-difference cases were executed; the source review independently executed 48 arithmetic assertions. These diagnostics are not substitutes for general Lean proofs. The interval-selection and open-component units also recorded their pre-strategy tests before coding.

The checks excluded cancellation of zero amplitudes, division by derivative order zero, unjustified regularity at component endpoints, counting by pointwise rather than uniform finiteness, treating disconnected sets as a single interval, inferring positive interval length from a singleton, and treating totalized `deriv` as evidence of differentiability. The formal results now handle the corresponding permitted boundary cases. Signed superlevels are essential to the local argument; a bound on absolute derivative alone across arbitrarily many oscillations would not suffice.

A constant centerline of arbitrary height shows that Lipschitz control alone cannot bound its unshifted zero-order amplitude by interval length. The new centering lemmas prove the correct auxiliary amplitude and positive-derivative identities without redefining the actual centerline. Surrounding manuscript translation conventions at I1309/I1323 and positive-order uses at I2729/I2777 were inspected. This is an application/normalization obligation, not a newly established manuscript error. No fatal flaw, readily repairable error, or typo is asserted in this batch; no repair or manuscript edit is made.

## Exact unresolved obligations and classification

1. **Implementation/application difficulty: same-centerline preparation at I1263.** Starting with the unchanged `BufferedFormattedSpanningPlanarGraphArc`, construct actual regular intervals with a coefficient-uniform bound on their number and a retained interval of length comparable to the full projection span. Supply C^N regularity and the bounded graph format for h-h(q0) on those intervals. Apply the new finite-list theorem, bound the component count of its common good set, then produce a closed good interval with uniform positive length fraction. The generic interval-selection theorem requires those mass and count hypotheses and does not prove this instantiation. The desired final statement must retain the same h, sign, path, format, span, offset and W/4 containment, with constants depending only on the manuscript's fixed data.
2. **Missing library/application infrastructure: full preparation lemma I933-954.** Prove the two-variable horizontal/vertical slicing and Fubini construction with the actual finite mixed-derivative list and scale factors L1^(-alpha1)L2^(-alpha2). The current one-variable theorem does not certify the full rectangle statement. The generic component-bound theorem can accept counts for nonsemialgebraic primitives, but the application to a monotone flux parameter still needs the algebraic differentiated-expression/count transfer and its actual s-interval scales. Relative and characteristic preparation remain separate obligations.
3. **Missing geometric application: actual bands and endpoints I1259/I1263.** Construct uniformly bounded-format components of W/2<rho<4W, assign the original W<=rho<2W labels, and prove boundedness, preconnectedness and appropriate separated endpoints at scale L0=max(W,diam C). The inherited containment theorem still requires its displayed positive-width buffer. These are manuscript hypotheses/application obligations, not flaws.
4. **Missing measure/application infrastructure: area and packing I1261/I1263.** Prove retained strip area comparable to length(J)*W with length(J) comparable to L0, the boundary-tube/local-enlargement estimates, and delta-square label packing. Pointwise containment and a generic preparation good set do not establish them.
5. **Remaining downstream project work.** Endpoint-region area, dyadic rounding, joint measurability and multiplicity, incidence/tails/moments/necessity and smooth-amplitude uniformity remain as recorded in the canonical checklist. `MainStatement` still has no theorem proof, and the full main-theorem correspondence graph is not complete.

Next concrete task: construct the selected centerline's actual uniformly controlled regular pieces and centered graph-format bridge, apply the new finite-list preparation theorem, then obtain a comparable closed good interval while retaining the same geometric witness.

## Execution limits and preservation

Final affected-unit build, aggregate type/body/axiom audit, root build and pinned-environment checks all exited zero with stable sources. All 49 axiom lists contain exactly propext, Classical.choice and Quot.sound. The compiled project closure has 177 nodes and no unexpanded dependencies; the final finite-list theorem reaches 156. No sorry, admit, unsupported custom axiom or prohibited native-evaluation proof mechanism occurs in the completed scope. Metadata `run_cmd` inspection is not a proof mechanism.

Development elaboration failures are retained with actual logs; they concern tactic/API/scope details, not added mathematical assumptions. Every current mathematical unit and audit driver was executed. Historical drafts remain provenance and are not newly certified. A fresh complete offline restoration is not claimed: the pinned runtime and checkpoint125 recovery kit were reused. No manuscript, inherited theorem source, pin or policy file was changed. The integration root gained only the two documented imports.
