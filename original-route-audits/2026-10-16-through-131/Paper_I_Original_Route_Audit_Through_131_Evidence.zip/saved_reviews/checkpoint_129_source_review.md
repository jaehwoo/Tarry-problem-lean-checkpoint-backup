# Checkpoint129 source and statement review

## Result and recovery provenance

Full manuscript verification remains incomplete, including verification relative
to the accepted published inputs. This batch verifies the actual area of the
prepared buffered strip and its same-witness integration into the uniform path
construction at I1263. It does not prove the whole buffered-strips lemma or the
main theorem.

The failed checkpoint128 save was repaired first. Workspace maintenance had
removed the unsaved final project and compiler. The saved full checkpoint127
and checkpoint128 progress were restored. The progress contained 16 declarations
(13 proofs, three definitions). Five proofs and one definition were reconstructed
from that progress and its recorded mathematical scope, then compiled and
audited. The resulting 22-declaration recovery update was successfully saved
before the new area work. It is a checked reconstruction, not a claim to have
recovered the missing final128 bytes. The receipt is
evidence/checkpoint_129_recovered_save_receipt.json.

Available other-chat retrieval recovered the already incorporated original
centerline work after123; no newer independent final proof was found to merge.
This is not a claim to have exhaustively accessed every other chat. Both the
Hardt endpoint route and the original cylindrical path/subdivision route remain
in the project, with their previous evidence unchanged.

The final audited scope has 36 declarations: 30 proofs and six definitions in
seven modules. Of these, 22 re-establish the prior checkpoint's documented
scope; the new substantive area batch is 12 proofs and two definitions in
SignedPlanarStripArea and AreaCertifiedPreparedPlanarArc. No published contract
was added. All 36 declarations have standard-only transitive axiom lists.

## Exact mathematical content

For either coordinate i in Fin 2 and sign sigma in {+1,-1}, the signed-coordinate
map from the actual Euclidean plane to the product of two real lines is
injective and volume preserving. A point is in signedPlanarStrip exactly when
its longitudinal coordinate belongs to J and its transverse deviation from h
has absolute value at most w. These statements use the existing strip
definition, not a replacement region or a new graph witness.

If h is continuous only on [a,b], the actual closed strip is measurable and
its ENNReal volume is ofReal(b-a) * ofReal(2*w). No global measurability of h
is assumed. A piecewise extension agrees with h on the interval, permitting
Fubini with closed vertical sections. Their volumes are ofReal(2*w) after translation.
Volume preservation transfers this literal closed-region formula to the
original Euclidean strip. For a<=b and w>=0 its real area is (b-a)*(2*w).
For transverse half-width W/4 the exact area is (b-a)*W/2.

If Cspan>0, Kprep>0, W>=0, u<=v and
R <= Cspan*Kprep*(v-u), the area is at least
R*W/(2*Cspan*Kprep). The denominator's positivity is explicit, not inferred
from the desired conclusion. The lower bound needs no positivity assumption
on R; the integrated nondegenerate path application supplies R>0 from distinct
endpoints.

AreaCertifiedPreparedPlanarArc retains every field and the same existential
witnesses of PreparedBufferedSpanningPlanarGraphArc, then appends measurability,
exact area and the macroscopic lower bound. The forget theorem checks this
relationship. The application theorem extracts the existing witnesses and
reuses them literally; it does not merely produce an unrelated strip of large
area. Retained data include the path, both coordinate indices, sign, h, full
projection span, graph-format polynomials, full-domain buffer, closed prepared
interval, analyticity on its neighborhood, all centered derivatives through
N, and all positive derivatives of the original h through N.

The final uniform theorem keeps the seven named published inputs and chooses
sPath,dPath,K,sCenter,dCenter,Cprep,Kprep after s,D,N but before the polynomial
coefficients, set, ambient E, width W, endpoints and path. Cprep>=1 and
Kprep>0 remain explicit. For a bounded preconnected sign-described S, W>0,
a pointwise W/2 buffer, and distinct a,b in S, it constructs the same original
path and subdivision with a selected area-certified prepared arc. In this
application Cspan=2*K, so the lower bound is R*W/(4*K*Kprep). K>0 is derived
from n+1<=K; no new geometric positivity premise was added. Neither the
original definitions nor the manuscript hypotheses were changed.

## Correspondence and proof route

| Source | Lean module/declarations | Covered scope |
| --- | --- | --- |
| I950, I1263 preparation | RegularCenterlineInterval, CenteredGraphFormat, PreparationGoodComponents, PreparedCenterlineInterval | Recovered regular interval, centered format, simultaneous derivative good components and comparable closed interval |
| I1263 same strip after preparation | PreparedBufferedPlanarArc | Recovered preparation preserving the original geometric witnesses and transverse containment |
| I1263 final strip-area sentence; I1250-1253 area/parameterization | SignedPlanarStripArea | Signed-coordinate measure preservation, closed-section Fubini, exact Euclidean area and its lower bound |
| I1263 path/subdivision through retained strip | AreaCertifiedPreparedPlanarArc | Same-witness integration of all earlier fields and actual area; uniform constants still precede all instance data |
| I1257, I1259, I1261, I1265 | Existing open checklist obligations | Actual bands, small-diameter branch, packing, endpoint region and measurable assignment NOT proved by this batch |

This is not a Hardt-free project. Hardt remains an accepted named input to the
uniform path/component machinery. The current integration uses the original
cylindrical path, uniform analytic/sign subdivision and divided-difference
preparation, with Hardt counting the common good set's components. The new
Fubini calculation supplies the original argument's omitted area calculation;
it is not an alternative proof of the full lemma. Previously saved alternative
Hardt endpoint and qualitative-QE centerline proofs remain separately labeled.
Their existence alone does not verify the original intermediate arguments.

The exact published inputs of the final theorem are:
PublishedCylindricalInitialBandDecomposition,
PublishedCompatibleSemialgebraicHardtTriviality,
PublishedQuantitativeRealQE, PublishedOneVariableNashRegularity,
PublishedFiniteConnectedCover, PublishedPiecewiseNashExtensions and
PublishedEquispacedDividedDifferenceMeanValue. They are explicit theorem
parameters, not added global axioms or supplied inhabitants. Their accepted
source/applicability records are retained. Standard-only #print axioms output
does not prove these parameters. The area lemmas and area-attachment bridge
introduce no external mathematical input.

## Obstructions and boundary tests

Before new mathematical implementation, checkpoint129_pre_strategy.py ran 270
exact rational scale tests and 72 constant-strip area tests. It retained the
saved strict-margin, positive-amplitude, endpoint and offset obstructions.
Those diagnostics are not proofs; the general formulas were subsequently
proved by Lean. Their JSON and actual command evidence are saved.

The checks cover both signs and coordinate choices; sigma=0 collapses the
longitudinal coordinate and is not allowed. Negative width gives the empty
strip; width zero gives area zero. Reversed and singleton intervals have area
zero under the ENNReal formula. Constant centerlines with arbitrary vertical
offset are allowed. No raw order-zero height bound is claimed: order zero is
for h-h(left), while positive derivatives are those of the original h.
N=0 is permitted. Coinciding endpoints do not supply a positive comparable
interval, so the uniform large-span theorem retains distinct endpoints.
Closed and open strips were not equated as sets. Interval-only continuity was
not replaced by a global regularity assumption.

## Actual execution and review

The saved Lean 4.19.0 compiler, nine pinned dependency sources and checkpoint125
cache were freshly restored and used. The compiler hash, exact revisions,
restore commands and logs are saved. Mathlib remains pinned at
c44e0c8ee63ca166450922a373c7409c5d26b00b. All 797 inherited source/policy/manuscript
baseline entries match, except the root module's explicitly recorded added
imports. The root build includes every relevant module. This is not merely
unexecuted proposed Lean code.

All 36 actual compiled types and all six definition bodies were reviewed,
including the 22 recovered declarations previously reviewed in this same
iteration. Both new source files were read in full. Quantifier order, ranges,
signs, endpoint restrictions, exact measure, centering, uniformity, retained
published parameters and same-witness fields were compared to I1263 and its
surrounding uses I1242-1272. No new manuscript error was established; no repair
or manuscript edit was made. Existing findings remain in the inherited record.

Final affected-unit build, aggregate type/body/axiom audit, root integration
and pinned-environment check all exited 0 with stable Lean source hashes.
The completed project-declaration closure has 976 nodes and zero unexpanded
nodes; the integrated area theorem reaches 974 nodes. 5891 unchanged inherited
dependency records were reused after source-hash verification, and 56 records
were collected for this scope. These are not manuscript completion percentages.
No sorry, admit, unsupported custom axiom or native-evaluation proof mechanism
appears in the completed transitive scope. The literal axiom output is saved
and reproduced in the correspondence report, including its line wrapping.

Failed development attempts remain in the command history. They concerned
Lean syntax/lemma selection in the reconstruction, coordinate/swap and interval
set simplification, measurability of absolute value, and one audit invocation
without Lake's environment. The latter was rerun with `lake env lean` and
passed. No failed attempt was reported as a verified proof, and none was
resolved by adding a mathematical assumption.

## Remaining exact obligations and classifications

The following remain project obligations, not defects of accepted citations.
Execution is now available. No mathematical counterexample is asserted for
these unresolved statements; the blockers are missing project infrastructure
or implementation, not unavailable execution.

1. I1259/I1263: for rho(x)=dist(x,E^c), construct the uniformly bounded-format
components C of W/2<rho<4W that receive labels from W<=rho<2W; prove the
required boundedness, preconnectedness and W/2 buffer. With
L0=max(W,diam C), in the large-diameter branch select a,b in C with
dist(a,b)>=c*L0 for a fixed positive c. Supply the small-diameter ball/strip
branch when diam C<=C0*W. The new area theorem is conditional on these
instance data until this application is constructed. Category: missing
geometric application infrastructure. This is the next concrete task.

2. I1261: decompose the boundary in an O(L0) ball into boundedly many monotone
arcs and points, prove total length O(L0), and bound their 4W neighborhood and
the required local-width enlargement by C*L0*W (using W<=L0). Obtain the
delta_P-square count <=P^C*L0*W and combine it with the given per-square
index count. Category: missing arclength/tube-area/packing implementation.

3. I1265: bound the candidate endpoint region relative to every assigned
anchor by C*L0^2; prove dyadic/subunit rounding changes comparisons only by
powers of P when W>=c*delta_P; construct choices jointly Borel in the original
parameters, with fixed ties and the stated multiplicity. Category: missing
geometric/measure and parameterized-selection application infrastructure.

4. I932-954: for the original rectangle and prescribed finite list, construct
one common measurable G with area(R\G)<=epsilon*L1*L2 and mixed derivative
bounds |partial^alpha f|<=C*B_f*L1^(-alpha1)*L2^(-alpha2), all constants
chosen uniformly before instance data. Transfer the algebraic expression
counts to monotone flux parameters using the actual flux-interval scales;
retain relative, characteristic and first-derivative-amplitude variants.
Category: missing two-variable Fubini and flux-transport implementation.
The new one-dimensional closed-strip Fubini formula does NOT discharge this.

5. Complete common assignments, physical incidence, tails, moments, necessity,
smooth-amplitude uniformity and full original argument correspondence along
the master checklist. In particular no proof of PaperI.MainStatement is
constructed: the cube membership threshold equivalence and SmoothUniformBound
remain conditional on unresolved project results. Category: unresolved
project assembly/implementation. The entire main checklist still contains
unexpanded references; the exact list is saved, not treated as proved.

New area and recovered reconstruction code were executed. Future recipes in
the restore instructions and the mathematical obligations above are clearly
not execution claims. No replacement proof or additional assumption closes
these remaining obligations in this iteration.
