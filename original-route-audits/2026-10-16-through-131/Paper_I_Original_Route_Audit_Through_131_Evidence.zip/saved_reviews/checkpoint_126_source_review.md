# Checkpoint126 source and statement review

The reviewed scope is 11 new theorem proofs and three definitions in
`PlanarTransverseStrips` and `BufferedFormattedPlanarArcs`, plus integration of
13 already checked original-route theorem proofs and five definitions from the
other chat's recovered After123 edition. The imported three modules are
byte-identical to that saved edition. They are integration work here, not 13
new discoveries or newly authored proofs. All 32 compiled types and all eight
printed definition bodies were inspected in the successful current audit.

The unchanged authoritative target is Paper I, `geo:planar-strips`, I1242-1266,
especially I1263. Fixed-format convention I623 and the original path argument
I647-655 supply the retained format and path context. The next preparation
application refers to I929-954. The manuscript SHA256 values remain:

- Paper I: `91c19e28f6e6a0733505ce066d6a42be9bfb6df1c8c31185849bc4b34b0ab914`.
- Supplement: `31b5340997aac383d037029596d1c52c88679cab366263b25ecda7d594aef312`.

## Correspondence and exact scope

| Manuscript statement | Lean declaration or definition | Scope |
| --- | --- | --- |
| Fixed-format centerline from the original restricted path | `published_signedPlanarCenterline_uniform_format` | Imported original affine substitution plus quantitative-QE argument; output budgets precede all coefficients and cuts |
| Same macroscopic graph arc, with uniform centerline format | `published_cylindrical_uniform_formatted_macroscopic_planar_arc` | Imported original-route assembly; same path, partition, indices, sign, function, Lipschitz constant and Euclidean span |
| Transverse displacement of the centerline | `signedPlanarStripPoint`, `signedPlanarStripPoint_dist` | Exact Euclidean displacement equals the absolute transverse parameter |
| Transverse enlargement stays inside E | `signedPlanarStrip_subset_of_path_buffer`, `signedPlanarStrip_subset_of_half_width_buffer` | Closed half-width W/4 contained in E from positive W and distance buffer at least W/2 |
| Centerline points belong to the same path | `signedPlanarStripPoint_zero_eq_path` | Uses the existing onto and along-path matching hypotheses, with the same time witness |
| Retaining a later good interval preserves containment | `signedPlanarStrip_mono_domain` | Any subset of the longitudinal interval; no assertion that a good interval has yet been constructed |
| Combined original path, format, span and containment | `published_cylindrical_uniform_buffered_formatted_macroscopic_planar_arc` | Five bounds precede the set coefficients, E, W and endpoints; the same chosen witness carries all conclusions |

The new `BufferedFormattedSpanningPlanarGraphArc` extends the witness data of
`FormattedSpanningPlanarGraphArc` with containment for every longitudinal subset.
Its forgetful theorem checks that the pre-existing data are preserved. No old
definition or theorem is changed. The root receives one additional import.

Distances and the ambient E are represented with `WithLp 2 (Fin 2 -> Real)`;
the proof uses the Euclidean metric rather than the coordinate-function sup
metric. The strip points are exactly the old signed decoder evaluated at
`(q,h(q)+u)`. Distinct axes and sign in {1,-1} are retained when identifying
the centerline with the path. The displacement lemma itself needs neither
restriction on the sign because the longitudinal coordinate is unchanged.

The five integers `sPath,dPath,K,sCenter,dCenter` are chosen from the original
input format and accepted inputs before A, S, E, W, a or b. The original
Euclidean endpoint estimate remains `dist(a,b) <= 2*K*longitudinalSpan`.
The universal half-width factor 1/4 has no coefficient, endpoint, width or
component dependence. The geometry lemma is valid for any E satisfying the
displayed distance buffer; it does not manufacture the manuscript's actual
bands or assert their other properties.

## Obstructions and boundary cases tested before implementation

The other route's 86 recorded pre-strategy checks are preserved and reused;
its proof strategy is unchanged. This batch additionally executed 108 exact
rational displacement checks across both axes, both signs, offsets, and zero
or nonzero transverse displacements. These finite diagnostics are not Lean
proofs; the general displacement identity is now checked by Lean.

For the open Euclidean unit ball, a center at zero has buffer 1 but the closed
half-width-1 strip reaches (0,1), which is outside the ball. Thus the generic
closed-strip theorem requires w<r, not just w<=r. This is satisfied by W/4<W/2
for positive W. The manuscript already uses a sufficiently small absolute c
and positive dyadic widths; this check is not a manuscript flaw or a new
condition imposed on its bands.

Empty longitudinal domains and negative half-widths give empty strips, with
Lean proofs included. Singleton domains, coincident endpoints, constant paths,
stationary points and noninjective time fibers are allowed. No positive area
or positive longitudinal length is inferred in these cases. W=0 would not
supply a positive buffer; the application retains W>0. Mathlib's real-valued
infDist convention is zero for the empty complement, so no positive buffer is
inferred from that convention. The actual bounded-open E application remains
separate. The arbitrary extension of h outside its projection interval is
never claimed semialgebraic or controlled by this strip theorem.

## Accepted inputs, route reconciliation and departures

No new external contract is introduced. The integrated theorem retains exactly
these six named published inputs:

1. `PublishedCylindricalInitialBandDecomposition`;
2. `PublishedCompatibleSemialgebraicHardtTriviality`;
3. `PublishedQuantitativeRealQE`;
4. `PublishedOneVariableNashRegularity`;
5. `PublishedFiniteConnectedCover`;
6. `PublishedPiecewiseNashExtensions`.

They remain explicit theorem parameters, with no assumed inhabitant or custom
axiom. The existing source-acceptance and applicability records are retained.
The quantitative-QE contract is the existing coefficient-uniform output-format
interface; its source review and limited correction search are preserved in
the imported evidence, without claiming a new independent citation proof.

The original-route centerline projection and its same-witness macroscopic
assembly are now integrated in this project. Checkpoint125's qualitative-QE
universal-family alternative remains unchanged. The new containment proof is
the manuscript's pointwise buffer argument, made explicit by the Euclidean
distance identity and `Metric.ball_infDist_compl_subset`. The choice c=1/4 and
a closed transverse interval fit within that argument; they do not replace
the path or require a positive speed. Both endpoint-path routes are preserved.
The active endpoint constructor is the CAD/curve route. Hardt remains in
inherited scalar counting/subdivision; no wholly Hardt-free claim is made.

## Exact remaining obligations and classifications

1. **Missing application and analytic infrastructure — preparation at
   I933-954/I1263.** On each selected regular interval I of length L>0, for a
   finite list of smooth scalars f with |f|<=B_f and fixed-format algebraic
   derivative expressions, prove the manuscript's one-variable implication:
   for each fixed N and epsilon>0 there are C depending only on format, N,
   epsilon and the fixed list, and G subset I, with length(I\G)<=epsilon*L and
   |f^(j)(q)|<=C*B_f*L^(-j) on G, for all listed f and 0<=j<=N. The original
   argument uses the uniform interval-component bound for signed derivative
   superlevel sets and the cited divided-difference estimate. Apply this to
   the same centerline on the needed regular pieces, justify every required
   derivative-expression format and amplitude bound, and retain one interval
   of length comparable to the original projection length. No such common
   good set, derivative bound or comparable interval is proved here.
2. **Missing geometric application — actual bands/endpoints at I1259/I1263.**
   For rho(x)=dist(x,E^c), construct the fixed-format components of
   W/2<rho<4W, with uniform count and assignment of the labels from
   W<=rho<2W. Supply preconnectedness, boundedness, and two points separated
   by a fixed proportion of L0=max(W,diam C) in the large-diameter case. The
   new theorem is conditional on the displayed positive width and buffer
   hypotheses until instantiated on those actual components. These are
   conditions already present in the manuscript, not mathematical flaws.
3. **Missing measure/application infrastructure — area and packing at
   I1261/I1263.** Prove the area of the retained signed-coordinate strip is
   comparable to length(J)*W, and length(J) is comparable to L0. Prove the
   boundary-tube and local-enlargement estimates, then the delta_P-square
   count and label packing. Pointwise containment alone does not imply these.
4. **Remaining downstream manuscript work — I1265 onward.** Prove endpoint
   region area relative to each assigned anchor, dyadic rounding, jointly
   measurable choices and multiplicity, then the unchanged incidence, tails,
   moments, necessity and smooth-amplitude uniformity obligations recorded in
   the canonical checklist. `MainStatement` still has no theorem proof. Its
   complete fine-grained manuscript dependency correspondence remains open.

No mathematical counterexample to a manuscript statement was established in
this scoped review. No fatal flaw, repairable error or typo is newly asserted,
and no manuscript repair or edit is proposed. The strict-margin diagnostic is
a boundary check on an overstrong helper candidate, resolved before coding.

## Execution and scope limits

Each mathematical unit compiled in the retained pinned Lean4.19.0/mathlib
environment. Final source-stable unit, type/axiom audit, root and environment
gates all exited 0. All 32 transitive axiom outputs contain only propext,
Classical.choice and Quot.sound. The audit's metadata commands inspect compiled
declarations; they are not proof mechanisms. No native-evaluation proof,
sorry, admit or unsupported custom axiom is used by the completed scope.

All five current mathematical modules and the current audit driver were
executed. No current mathematical draft is being presented as an unexecuted
proof. Historical drafts and audit drivers remain provenance and are not
newly certified merely by their presence. The inherited compiler and recovery
kit were reused; this iteration does not repeat the large cache packaging or
claim a fresh complete offline restoration. The complete project is not
verified, even though the explicitly covered scope passed.
