"""Read-only reconciliation of saved sources and compiled dependency exports.

This is NOT a Lean compiler run or a proof checker. It validates provenance,
traces saved kernel-reference exports, and repeats finite boundary diagnostics.
It never changes the recovered project, manuscripts, or canonical checklists.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb, factorial
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
BASE = WORK / 'checkpoint130/PaperILean'
NEW = WORK / 'latest131'
OLD = WORK / 'original_after123'
OUT = HERE / 'Route_Audit_Evidence.json'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text())

# Repeated before proposing the next original-route bridge; finite tests only.
diagnostics = {'divided_difference': 0, 'scale_comparison': 0,
               'strict_band': 0, 'signed_strip': 0}
for j in range(1, 13):
    a, h = F(-7, 3), F(5, 11)
    s = sum((-1)**(j-i)*comb(j, i)*(a+i*h)**j for i in range(j+1))
    assert s == factorial(j)*h**j
    assert sum(comb(j, i) for i in range(j+1)) == 2**j
    l, r = F(-9, 7), F(13, 5)
    nodes = [l+(r-l)/4+i*(r-l)/(2*j) for i in range(j+1)]
    assert all(l < x < r for x in nodes)
    assert nodes[-1]-nodes[0] == (r-l)/2
    diagnostics['divided_difference'] += 4
for ell in [F(1, 100), F(1), F(8)]:
    for K in [1, 2, 7]:
        for L in [ell, 2*ell, 4*K*ell]:
            for N in [0, 1, 4]:
                for n in range(N+1):
                    assert ell/ell**n <= (4*K)**N*L/L**n
                    diagnostics['scale_comparison'] += 1
for W in [F(1, 1000), F(1), F(19)]:
    for r in [0, W/2, W, 2*W, 4*W, 5*W]:
        assert (W/2 < r < 4*W) == (W*W < 4*r*r and r*r < 16*W*W)
        diagnostics['strict_band'] += 1
    assert 2*(W/4)**2 < (W/2)**2
    for axis in [0, 1]:
        for sign in [-1, 1]:
            for offset in [F(0), F(10**6)]:
                det = sign if axis == 0 else -sign
                assert abs(det) == 1
                assert (offset+W/4)-(offset-W/4) == W/2
                diagnostics['signed_strip'] += 1
assert F(10**6) > 1  # Raw height is not controlled by a Lipschitz constant.
assert F(7, 8)-F(1, 8) > F(1, 2)  # No diameter attainment needed in (0,1).
assert (-1)**2 == 1**2 and -1 != 1  # Sign needed in a squared-distance graph.
assert 3**2+4**2 != max(3, 4)**2  # Euclidean versus sup distance.
diagnostics['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
diagnostics['status'] = 'Exact rational finite diagnostics passed; not universal proofs.'

baseline = read(NEW / 'evidence/checkpoint_131_baseline.json')
baseline_bad = [name for name, sha in baseline.items()
                if not (BASE/name).exists() or digest(BASE/name) != sha]
assert not baseline_bad, baseline_bad

original_names = ['BoundedTimeProjection.lean', 'SignedPlanarCenterlineFormat.lean',
                  'OriginalRouteFormattedPlanarArcs.lean']
original_match = {name: digest(BASE/'PaperILean'/name) == digest(OLD/'PaperILean'/name)
                  for name in original_names}
assert all(original_match.values())

declaration_sets = [
    (BASE, 'reports/Checkpoint126_CompletedDeclarations.json'),
    (BASE, 'reports/Checkpoint127_CompletedDeclarations.json'),
    (BASE, 'reports/Checkpoint128_Recovered_CompletedDeclarations.json'),
    (BASE, 'reports/Checkpoint129_CompletedDeclarations.json'),
    (BASE, 'reports/Checkpoint130_CompletedDeclarations.json'),
    (NEW, 'reports/Checkpoint131_CompletedDeclarations.json'),
]
record_checks, selected_records = [], []
all_records = {}
for root, rel in declaration_sets:
    records = read(root/rel)
    if isinstance(records, dict):
        records = records.get('declarations', records.get('records', []))
    mismatches = []
    for record in records:
        name = record['declaration']
        all_records[name] = record
        mod = record.get('module')
        expected = record.get('source_sha256')
        if mod and expected:
            path = root/mod
            if not path.exists():
                path = BASE/mod
            if not path.exists() or digest(path) != expected:
                mismatches.append(name)
    record_checks.append({'report': str((root/rel).relative_to(WORK)),
                          'declarations': len(records), 'mismatches': mismatches})
    assert not mismatches, mismatches

exports = read(NEW/'reports/Checkpoint131_KernelProjectDependencies.json')
graph = {}
for row in exports:
    deps = row['direct_project_dependencies']
    graph[row['declaration']] = deps.split(';') if isinstance(deps, str) and deps else deps or []
    if isinstance(graph[row['declaration']], str):
        graph[row['declaration']] = []

roots = [
    'PaperI.published_uniform_large_bufferedBand_prepared_arc',
    'PaperI.published_bounded_format_finite_list_preparation',
    'PaperI.published_uniform_bufferedDistanceBand_format_and_components',
    'PaperI.published_planarDistanceGraph_has_sign_description',
]
probes = [
    'PaperI.published_cylindrical_bounded_sign_format_piecewise_analytic_paths',
    'PaperI.PublishedQuantitativeRealQE.output_format',
    'PaperI.published_signedPlanarCenterline_uniform_format',
    'PaperI.published_bounded_actual_centerline_graph_format',
    'PaperI.published_signed_derivative_interval_strict_bound',
    'PaperI.PublishedEquispacedDividedDifferenceMeanValue.mean_value',
    'PaperI.published_cylindrical_coordinate_path_original_sign_variation',
    'PaperI.exists_macroscopic_planar_graph_piece',
]
closures = {}
for root in roots:
    seen, pending = set(), [root]
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        pending.extend(graph.get(name, []))
    missing = sorted(seen-set(graph))
    assert not missing, missing
    closures[root] = {
        'nodes': len(seen), 'unexpanded': missing,
        'reached_probes': {name: name in seen for name in probes},
        'hardt_endpoint_transport_references': sorted(n for n in seen if 'transportPath' in n),
        'nodes_sorted': sorted(seen),
    }
    if root in all_records:
        selected_records.append(all_records[root])

checklist = read(NEW/'reports/MasterChecklist.json')
ids = {'geo:paths', 'geo:preparation', 'geo:planar-strips', 'ARG:planar_centerline_format'}
rows = [r for r in checklist['items'] if r['id'] in ids]
summary131 = read(NEW/'evidence/checkpoint_131_final_verification_summary.json')
assert all(g['exit_code'] == 0 and g['sources_unchanged_during_execution']
           for g in summary131['gates'].values())
assert summary131['all_axioms_standard']

result = {
    'audit_date_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Original manuscript paths, preparation and buffered planar-strip route; not whole-paper verification.',
    'execution_boundary': 'Fresh hash/dependency reconciliation and rational tests only. Saved successful Lean runs inspected; no new Lean compiler run or new Lean theorem claimed.',
    'manuscript_sha256': {p.name: digest(p) for p in sorted((BASE/'manuscript').glob('*.tex'))},
    'checkpoint131_baseline_matches_checkpoint130': {'entries': len(baseline), 'mismatches': baseline_bad},
    'after123_three_modules_byte_identical': original_match,
    'declaration_record_source_checks': record_checks,
    'saved_kernel_export_records': len(exports),
    'dependency_closures': closures,
    'selected_compiled_records': selected_records,
    'checkpoint131_saved_verification': summary131,
    'metadata_lag': {'checkpoint': checklist['checkpoint'], 'active_iteration': checklist['active_iteration'],
                     'current_items': checklist['item_count'],
                     'meaning': 'Saved progress contains successful final gates but its canonical checklist and correspondence report still reflect checkpoint130/start-of131. This audit does not overwrite them.'},
    'relevant_saved_checklist_rows': rows,
    'boundary_diagnostics': diagnostics,
    'remaining': [
        'Uniform sign format for each actual band component, not merely the whole band or its component count.',
        'Large-arc derivative output scale ell to L0; upper span bound from same-path containment.',
        'Boundary-tube/local-enlargement upper area and square packing.',
        'Actual endpoint-region area, rounding, jointly Borel choices and multiplicity.',
        'Full two-variable/flux preparation and downstream manuscript assembly.',
    ],
}
OUT.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
print(json.dumps({
    'output': str(OUT), 'baseline_entries': len(baseline),
    'source_checks': record_checks, 'original_modules_unchanged': original_match,
    'closures': {k: {a:b for a,b in v.items() if a != 'nodes_sorted'} for k,v in closures.items()},
    'diagnostics': diagnostics,
}, indent=2))
