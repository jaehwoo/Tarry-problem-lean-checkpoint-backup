"""Generate the scoped original-route audit; no project or manuscript edits."""
from pathlib import Path
from xml.sax.saxutils import escape
import hashlib
import json
import zipfile
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
BASE = WORK/'checkpoint130/PaperILean'
NEW = WORK/'latest131'
OUT = WORK.parent/'output/pdf'
OUT.mkdir(parents=True, exist_ok=True)
PDF = OUT/'Paper_I_Original_Route_Audit_Through_131.pdf'
ZIP = OUT/'Paper_I_Original_Route_Audit_Through_131_Evidence.zip'
facts = json.loads((HERE/'Route_Audit_Evidence.json').read_text())

FONTROOT = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/share/fonts/truetype')
for n, fn in [('DV','DejaVuSans.ttf'),('DV-Bold','DejaVuSans-Bold.ttf'),('DV-Italic','DejaVuSans-Oblique.ttf')]:
    pdfmetrics.registerFont(TTFont(n, str(FONTROOT/fn)))
pdfmetrics.registerFontFamily('DV', normal='DV', bold='DV-Bold', italic='DV-Italic', boldItalic='DV-Bold')
NAVY = colors.HexColor('#15344A')
TEAL = colors.HexColor('#147C80')
GRAY = colors.HexColor('#52616B')
LIGHT = colors.HexColor('#EFF5F7')
styles = {
    'Title': ParagraphStyle('Title', fontName='DV-Bold', fontSize=24, leading=28, textColor=NAVY, spaceAfter=11),
    'Subtitle': ParagraphStyle('Subtitle', fontName='DV', fontSize=10, leading=14, textColor=GRAY, spaceAfter=17),
    'H1': ParagraphStyle('H1', fontName='DV-Bold', fontSize=19, leading=24, textColor=NAVY, spaceAfter=14),
    'H2': ParagraphStyle('H2', fontName='DV-Bold', fontSize=11.5, leading=16, textColor=TEAL, spaceBefore=11, spaceAfter=6, keepWithNext=True),
    'Body': ParagraphStyle('Body', fontName='DV', fontSize=9.8, leading=14.1, spaceAfter=8),
    'Small': ParagraphStyle('Small', fontName='DV', fontSize=8.2, leading=11.7, textColor=GRAY, spaceAfter=6),
    'Cell': ParagraphStyle('Cell', fontName='DV', fontSize=8.8, leading=12.2, spaceAfter=0),
    'HeadCell': ParagraphStyle('HeadCell', fontName='DV-Bold', fontSize=8.6, leading=12, textColor=colors.white),
    'Formula': ParagraphStyle('Formula', fontName='DV', fontSize=10.5, leading=17, textColor=NAVY, backColor=LIGHT, borderPadding=9, spaceBefore=4, spaceAfter=13),
    'Code': ParagraphStyle('Code', fontName='DV', fontSize=8.1, leading=11.4, textColor=NAVY, wordWrap='CJK', spaceAfter=5),
}
story=[]
def p(t, sty='Body'):
    story.append(Paragraph(t, styles[sty]))
def heading(t): p(t,'H2')
def code(t): p(escape(t),'Code')
def table(head, rows, widths):
    data=[[Paragraph(escape(x),styles['HeadCell']) for x in head]]
    data += [[Paragraph(x,styles['Cell']) for x in row] for row in rows]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,LIGHT]),
        ('LINEBELOW',(0,0),(-1,0),.6,NAVY),
    ]))
    story.append(t)
    story.append(Spacer(1,9))
def page(title):
    story.append(PageBreak()); p(title,'H1')

p('Original argument audit','Title')
p('Paper I | Updated through saved checkpoint 131 | 16 October 2026','Subtitle')
p('<b>Verdict.</b> Substantial parts of the manuscript’s original route have now been formalized using accepted published inputs. The active large-strip theorem keeps the CAD/curve-selection path, the original restricted-path quantitative-QE centerline, and the signed-superlevel/divided-difference preparation argument. It does not use the alternative Hardt endpoint-transport proof. This is not yet a formalization of the complete buffered-strip lemma, the full preparation lemma, or the manuscript.')
p('There are genuine supporting proof substitutions, some harmless formal elaborations, and outstanding application bridges. These should not be conflated. No fatal manuscript defect was established by this scoped audit. The possible inclusion of uncentered order zero needs an explicit interpretation (page 3).')
heading('What changed since the recovered original-route branch')
table(['Saved stage','Original-route progress','Important limitation'],[
    ['After123 / 126','The original quantitative-QE centerline modules were incorporated byte-for-byte. W/4 transverse containment was added.','The qualitative-QE alternative from checkpoint 125 also remains, but is not used by the current large-strip theorem.'],
    ['127','Signed derivative superlevels, interior divided-difference stencils, exceptional-length bounds, and one common finite-list good set.','This is a one-dimensional theorem; it is not the whole rectangle/flux preparation lemma.'],
    ['Recovered 128 / 129','Preparation on the same centerline, a comparable closed interval, and exact area of the same strip.','Positive derivatives concern the original h; order-zero control concerns h - h(q₀).'],
    ['130','Actual enlarged bands and components, separated endpoints, small rectangle, and the large-branch application.','The large branch still assumes the selected component has the required uniform sign format.'],
    ['131 progress','Distance graph, uniform format of the whole band, Euclidean component transport, and a uniform component count.','No uniform sign description of each individual component yet. The saved checklist/report lags these executed results.'],
],[79,227,205])
heading('The exact scope of this review')
p('Main manuscript I623, I647-655, I929-954, I1242-1266, and relevant later normalization/jet uses. Both manuscript hashes match the earlier original-route edition. Historical alternatives remain preserved; no manuscript or existing proof was modified. Other parts of the paper were not exhaustively re-audited.','Small')

page('Where the proof differs')
table(['Location / issue','Current implementation','Classification'],[
    ['I654: endpoint path','The old compatible-Hardt transport construction is separate. The active path uses cylindrical towers, selected cell chains, and curve-selection germs.','Original geometric route restored. The accepted CAD input is an explicitly documented structural corollary, not a verbatim theorem.'],
    ['I623 / I654: uniform format','Some bounds use qualitative QE on a single universal coefficient family, then a finite maximum over Boolean sign tables.','A supporting uniformity proof substitution. It genuinely proves bounds before all coefficients; it is not pointwise finiteness. The printed quantitative complexity intermediate is not reproduced there.'],
    ['I654 / I950: uniform counts','Analytic/sign subdivision and superlevel counts use finite-cover/QE/Hardt machinery.','Hardt is still used for counting, not for the active endpoint path. The whole dependency chain is not Hardt-free. Triviality is already mentioned at I638.'],
    ['I1263: long graph arc','A maximum span plus the finite polygon inequality yields dist(a,b) ≤ 2Kℓ. The coordinate-variation theorem is separately present, but not called here.','A local proof simplification within the same graph-piece route. It avoids an unnecessary arclength/positive-speed parameterization; it does not change the selected path.'],
    ['I1259: distance minimum','A nearest point in the full closed complement is supplied by Euclidean properness. Squared-distance formulas are then eliminated.','A real local implementation difference: the bounded-search-region step is bypassed. It is mathematically sufficient; the literal bounded-search route remains easy to supply (page 4).'],
    ['I950: divided differences','Equations (41)+(44) are specialized to equally spaced nodes in the middle half of an open component; the manuscript cites (44)+(52).','Same analytic method. Extra formula identification and interior nodes change only the allowed order-dependent constant, not the argument.'],
    ['I1263: small branch and good interval','A concrete W/2 by W/2 rectangle replaces the informal small ball; strict good inequalities give a closed interior interval.','Formal elaboration with fixed constants. A smaller rectangle in the same buffered ball and an interior good interval supply the stated geometry.'],
],[94,226,191])
p('<b>Why these changes happened:</b> the source dependencies show reuse of existing generic uniformity/counting interfaces and replacement of implicit estimates by explicit metric and interval lemmas. That is evidence about the implementation, not evidence that the manuscript’s route is impossible. A successful theorem using another route cannot, by itself, certify a skipped original intermediate step.','Small')

page('Preparation: original method, precise scope')
heading('The divided-difference step is actually present')
p('For j ≥ 1, the accepted input is only the equispaced mean-value identity. The project proves the binomial absolute-sum bound, then chooses an interior stencil of spacing h = ℓ/(2j) in a signed superlevel component of length ℓ. It obtains:')
p('M h<super>j</super> ≤ 2<super>j</super>B, hence M ℓ<super>j</super> ≤ (4j)<super>j</super>B.<br/>With M = C B/L<super>j</super>, each component is short; a uniform component count controls total exceptional length.','Formula')
p('Both signs and the finite function/order list are combined into one measurable good set. The strict version handles zero amplitude without dividing by B. Order zero uses the amplitude hypothesis directly. The same-centerline application first selects an analytic interval, then retains a closed good interval of comparable length. Constants are selected before coefficients, amplitudes, endpoints, and the individual functions.')
code('PaperI.published_bounded_format_finite_list_preparation')
code('PaperI.published_bounded_format_lipschitz_prepared_interval')
p('The first theorem is proved for bounded-format semialgebraic function graphs. The manuscript also covers algebraic differentiated expressions in a possibly nonsemialgebraic flux parameter. The generic component-bound helper is suitable for that case, but the transfer to actual flux intervals remains unformalized. The two-dimensional horizontal/vertical/Fubini construction at I952 is also still open.')
heading('Order zero is a real statement-matching question')
p('A constant centerline h(q) = H on [0,1] is Lipschitz with fixed algebraic format for every H. Its raw height is not bounded by the interval length. The code therefore applies preparation to h(q) - h(q₀), proves equality of positive derivatives with those of h, and retains the original h in the geometric strip.')
p('<b>If I1252 is intended to include j = 0 in unshifted absolute coordinates, that literal interpretation is false.</b> Positive orders, or order zero in explicitly translated local coordinates, avoid the obstruction. I1309/I1323 discuss translation covariance and relative endpoints; I2729 uses j ≥ 2. Thus this audit records a normalization/notation ambiguity, not a demonstrated fatal defect of the intended theorem. The convention must also be kept consistent at I1272 and I3217. No text was edited.')
heading('Evidence that the original route is active')
p('The saved compiled dependency export gives a 995-node closure for the current large-band theorem, with no unexpanded project nodes. It reaches the CAD path constructor, quantitative-QE output-format field, original centerline theorem, and divided-difference mean-value field. It reaches neither Hardt endpoint-transport functions nor checkpoint125’s alternative centerline-format theorem.','Small')

page('What remains, and whether the original route works')
heading('1. Individual component format - the next substantive bridge')
p('Checkpoint131 proves uniform format for B(E,W) = {W/2 &lt; dist(x,Eᶜ) &lt; 4W} and uniformly many connected components. The large-strip theorem instead needs a uniform sign description of the particular component C containing the seed. A count alone does not provide that description.')
p('The required order is: for fixed input format (s,D), choose (sC,DC) <b>before</b> E, its coefficients, W, and the seed z, then describe the coordinate image of connectedComponentIn B(E,W) z with those bounds. The original route can use parameter-compatible cell decomposition, identify components by finite cell chains, and eliminate the resulting fixed family. This remains a project application proof; it must not be hidden in a new assumption of the desired strip conclusion.')
heading('2. Derivative scale ℓ → L₀ - a concrete local bridge')
p('The retained bounds are Cprep ℓ/ℓ<super>n</super>, where ℓ is the full selected projection span. The current geometry already gives L₀ ≤ 4Kℓ. Path containment supplies the other inequality: the projected endpoint distance is at most the Euclidean distance of those two path points, hence ℓ ≤ diam(C) ≤ L₀. For 0 ≤ n ≤ N and K ≥ 1:')
p('0 &lt; ℓ ≤ L₀ ≤ 4Kℓ<br/>Cprep ℓ/ℓ<super>n</super> ≤ Cprep (4K)<super>N</super> L₀/L₀<super>n</super>.','Formula')
p('This is a direct completion of the manuscript’s scale comparison, not a replacement geometric proof. The existing preparation_derivative_scale_comparison helper can be reused with amplitude ℓ and multiplier 4K, followed by ℓ ≤ L₀. This derivation is checked mathematically here and tested on exact rational cases; its attachment to the actual large-branch witness is <b>not newly Lean-checked</b>.')
heading('3. The literal bounded-search minimum can also be retained')
p('If E and x lie in [-T,T]² with T &gt; 0, y = (2T,x₂) lies outside E and dist(x,y) ≤ 3T. A nearest complement point is therefore in [-4T,4T]². Restricting the minimum to that closed bounded search region yields the manuscript’s formula. The saved code uses the full complement instead; no counterexample blocks the original bounded-search step. This specific localization is not newly Lean-checked.')
heading('4. Remaining geometry and preparation are not supplied by lower area')
p('Still open: the monotone-boundary/arclength-mesh tube upper bound, local-width enlargement and δP-square packing at I1261; actual endpoint-region area, rounding, jointly Borel choices and multiplicity at I1265; and full rectangle/flux preparation at I952-954. A contained strip of large area does not prove these upper bounds or measurable-selection claims. These are incomplete applications/infrastructure, not identified failures of accepted citations.')

page('Verification boundary and handoff')
heading('What was freshly checked in this audit')
table(['Check','Result'],[
    ['Source continuity','All 809 checkpoint131 baseline entries match checkpoint130. Both manuscripts and the three After123 original-route modules are unchanged.'],
    ['Declaration/source records','195 records across checkpoints126-131 match current source hashes. This checks provenance, not 195 new proofs or exhaustive semantics.'],
    ['Saved dependency exports','Closures: large-band strip 995 nodes; preparation 156; band format/count 135; distance graph 43. No unexpanded project nodes.'],
    ['Boundary diagnostics','48 divided-difference, 216 scale, 18 strict-band, and 24 signed-strip checks passed, with offset/norm/sign/diameter obstructions retained. These are finite tests, not general proofs.'],
    ['Saved checkpoint131 compiler evidence','Four modules: 19 proofs, 7 definitions. Unit, type/axiom, root and environment gates recorded exit 0 with stable sources and standard-only axioms.'],
    ['Fresh Lean execution','None in this audit. No new theorem, rebuild, or independently checked external theorem is claimed.'],
],[143,368])
heading('Accepted external inputs remain visible')
p('The large-band theorem retains seven inputs: cylindrical initial-band decomposition, compatible Hardt triviality, quantitative real QE, one-variable Nash regularity, finite connected cover, piecewise Nash extensions, and equispaced divided-difference mean value. Independent Lean proofs of accepted applicable citations are not required by the author’s policy.')
p('Standard axioms (propext, Classical.choice, Quot.sound) do not discharge these parameters. Source applicability, formal contracts, and local application proofs remain separate. CAD’s first-band input is a structural corollary, not a literal quotation. No new external contract was added.')
heading('Current status must not be inferred from a stale checklist alone')
p('The newest progress bundle has checkpoint131’s successful final gates, but its checklist still says checkpoint130 with an early “no new proof certified yet” entry. Its report is also checkpoint130’s. Thus checkpoint131 has source-verified progress but unfinished reporting reconciliation. Existing files were not overwritten.')
heading('Sources and recommended next task')
p('Primary applicability checks revisited: de Boor, <i>Divided differences</i>, equations (41) and (44), printed pp.60-61; Basu, <i>Algorithms in Real Algebraic Geometry: A Survey</i>, Definition 2.2 and Theorems 2.4/2.27. These support the recorded finite-difference, CAD, and QE interfaces; no new exhaustive errata search is claimed.','Small')
p('<link href="https://surveys-in-approximation-theory.com/papers/2/2.pdf" color="#147C80">de Boor publisher PDF</link> · <link href="https://arxiv.org/html/1409.1534v1" color="#147C80">Basu primary survey</link>','Small')
p('<b>Next:</b> derive the selected component’s bounded sign format from the original input format, then attach the ℓ-to-L₀ scale comparison. Continue with the manuscript’s boundary-tube/packing and joint-choice arguments. Do not replace these missing applications with an alternative endpoint route or declare the full lemma verified.','Small')

def footer(c, doc):
    c.setStrokeColor(colors.HexColor('#D1DDE2'))
    c.line(42,37,A4[0]-42,37)
    c.setFont('DV',7)
    c.setFillColor(GRAY)
    c.drawString(42,24,'Original-route audit | Saved evidence through 131 | Full manuscript incomplete')
    c.drawRightString(A4[0]-42,24,str(doc.page))

doc=SimpleDocTemplate(str(PDF),pagesize=A4,rightMargin=42,leftMargin=42,
    topMargin=39,bottomMargin=49,title='Paper I: Original Route Audit Through Checkpoint 131',
    author='OpenAI',pageCompression=1)
doc.build(story,onFirstPage=footer,onLaterPages=footer)

# Scoped evidence archive, not a stand-alone Lean project. Keep all inputs unchanged.
source_names=[
 'CylindricalCADInput.lean','CylindricalUniformEndpointPaths.lean','CylindricalMixedFiberPaths.lean',
 'CylindricalAnalyticPaths.lean','CylindricalCoordinateVariation.lean','PlanarMacroscopicArc.lean',
 'UniformMacroscopicPlanarArcs.lean','BoundedTimeProjection.lean','SignedPlanarCenterlineFormat.lean',
 'OriginalRouteFormattedPlanarArcs.lean','PlanarCenterlineFormat.lean','PlanarTransverseStrips.lean',
 'BufferedFormattedPlanarArcs.lean','PreparationDividedDifferences.lean','OriginalPreparationSuperlevels.lean',
 'OriginalOneVariablePreparation.lean','OriginalPreparationFiniteList.lean','CenteredPreparationAmplitude.lean',
 'RegularCenterlineInterval.lean','PreparedCenterlineInterval.lean','PreparedBufferedPlanarArc.lean',
 'SignedPlanarStripArea.lean','AreaCertifiedPreparedPlanarArc.lean','BufferedDistanceBandGeometry.lean',
 'BufferedBandSmallStrip.lean','BufferedBandPreparedArc.lean',
]
entries=[]
def add(path, arc):
    entries.append((path,arc))
for name in source_names: add(BASE/'PaperILean'/name,'sources/checkpoint130/'+name)
for path in sorted((NEW/'PaperILean').glob('*.lean')):
    if path.name != 'Batch131AxiomAudit.lean': add(path,'sources/checkpoint131/'+path.name)
for path in sorted((BASE/'manuscript').glob('*.tex')): add(path,'manuscript/'+path.name)
for name in ['AGENTS.md','VERIFICATION_POLICY.md','lean-toolchain','lake-manifest.json']:
    add(BASE/name,'context/'+name)
for n,rel in [(126,'Checkpoint126_CompletedDeclarations.json'),(127,'Checkpoint127_CompletedDeclarations.json'),
              (128,'Checkpoint128_Recovered_CompletedDeclarations.json'),(129,'Checkpoint129_CompletedDeclarations.json'),
              (130,'Checkpoint130_CompletedDeclarations.json')]:
    add(BASE/'reports'/rel,'saved_records/'+rel)
for rel in ['Checkpoint131_CompletedDeclarations.json','Checkpoint131_KernelProjectDependencies.json']:
    add(NEW/'reports'/rel,'saved_records/'+rel)
for path in sorted((NEW/'evidence').glob('*')):
    if path.name.endswith('.log') and any(x in path.name for x in ['011_','012_','013_','014_']):
        add(path,'saved_execution/'+path.name)
for rel in ['checkpoint_131_final_verification_summary.json','checkpoint_131_baseline.json','checkpoint_131_pre_strategy.json']:
    add(NEW/'evidence'/rel,'saved_execution/'+rel)
for rel in ['checkpoint_126_source_review.md','checkpoint_127_source_review.md','checkpoint_127_preparation_review.md',
            'checkpoint_129_source_review.md','checkpoint_130_source_review.md']:
    add(BASE/'evidence'/rel,'saved_reviews/'+rel)
for rel in ['check_route_evidence.py','make_route_report.py','Route_Audit_Evidence.json']:
    add(HERE/rel,'audit/'+rel)
manifest={arc: {'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
          for path,arc in entries}
readme=('Scoped evidence for Paper_I_Original_Route_Audit_Through_131.pdf.\n'
        'No new Lean compiler run or new theorem is claimed by this audit.\n'
        'sources/: selected exact, unchanged saved Lean files. This is not a complete buildable project.\n'
        'saved_execution/: retained checkpoint131 successful logs, not executions performed in this audit.\n'
        'saved_records/: actual compiled-type/dependency records from the saved project.\n'
        'audit/Route_Audit_Evidence.json: fresh source-hash, dependency, metadata-lag, and rational checks.\n'
        'The audit script expects the recovered checkpoint130 part1, checkpoint131 verified-source progress,\n'
        'and original After123 recovered evidence directories, as named in its WORK-relative paths.\n'
        'The complete original archives remain the authoritative build/recovery inputs.\n'
        'No manuscript, existing Lean proof, or canonical checklist was edited.\n')
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,arc in entries: z.write(path,arc)
    z.writestr('README.txt',readme)
    z.writestr('SHA256_Manifest.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'pdf':str(PDF),'evidence':str(ZIP),'evidence_members':len(entries)+2,
                  'pdf_bytes':PDF.stat().st_size,'zip_bytes':ZIP.stat().st_size},indent=2))
