# Verification policy: accepted published inputs

Effective 14 October 2026, by the author's explicit instruction. This policy supplements the existing proof-audit requirements and supersedes any older rule requiring an independent Lean proof of every external citation.

## Standard of acceptance

Accept an applicable published mathematical theorem as an external input unless there is an identified error, correction, retraction, or counterexample affecting the statement actually used. Publication is the authorized basis of trust; independent reproduction of the cited proof is optional. A missing Lean proof of that external result is not, by itself, a mathematical defect or an unfinished prerequisite under this standard. A bounded correction search is not a guarantee that no error exists.

Match the cited result to the needed statement. Retain its hypotheses, definitions, domains, parameter dependence and quantifier order. Apply known relevant corrections. Record uncertainty about an exact match or applicability honestly, without turning absence of a formalized external proof into evidence of falsehood. Do not silently strengthen a citation, assume a project-specific conclusion, or treat qualitative semialgebraicity as a quantitative format theorem.

## Lean representation and audits

Use explicit, named theorem parameters or proposition-valued structures for accepted external inputs. Prefer existing checked library theorems when they already provide the needed result. Do not add an untracked global axiom, an inhabitant of the external contract, `sorry`, `admit`, or unchecked evaluation to hide the trust boundary.

Lean must check each implication from those parameters and all project-specific application bridges. Record the actual compiled type, retained assumptions, direct project dependencies, source hash and transitive axiom audit. Standard `propext`, `Classical.choice` and `Quot.sound` are permitted. A standard-only axiom list does not prove an explicit theorem parameter; both the type and the axiom list must be inspected.

Each citation has separate source-acceptance, applicability and machine-proof statuses. A conditional theorem checked by Lean is a valid verified implication. When its input is an accepted applicable published result, the project may use its conclusion under this authorized verification policy. Describe it as verified using accepted published inputs, with those inputs named. Do not describe the external theorem itself as proved by Lean.

## Scope and continuation

Continue proving the manuscript's own arguments and checking their applications of external results. Independent formalization of quantifier elimination, Puiseux theory, or other accepted references is optional and must not automatically displace the remaining manuscript work. Preserve existing independent formalizations as useful verified work.

For the current real-algebraic interface, `PaperI.PublishedRealSemialgebraicity` records the qualitative finite-polynomial-sign consequence of ordered real-field quantifier elimination (Basu-Pollack-Roy, second edition, Theorem 2.77 and Corollary 2.78), in the project's actual encoding. The input ring formulas embed in the ordered-field language; this does not assert pure ring-language quantifier elimination. All 11 new corollaries retain this parameter. Quantitative output-format bounds, component/fiber bounds, selection and remaining global manuscript arguments require their own precise interfaces and application proofs.

Keep one canonical `reports/MasterChecklist.json` in each project checkout. Preserve its existing claims and newer progress; add this policy and conditional proof records without resetting checkpoint history. Use `tools/apply_published_assumptions_policy.py` after a legacy metadata generator if that generator would otherwise restore the old independent-reproof requirement. Keep verification relative to accepted inputs separate from verification of all dependencies inside Lean. Neither status is declared complete by this update.

The manuscript remains unchanged. Retain the existing mandatory pre-strategy obstruction tests and classify actual mathematical findings as fatal, repairable, or typographical. A change in the accepted trust policy is not itself a mathematical flaw. Reports must identify remaining project obligations rather than fabricate completed proofs.
