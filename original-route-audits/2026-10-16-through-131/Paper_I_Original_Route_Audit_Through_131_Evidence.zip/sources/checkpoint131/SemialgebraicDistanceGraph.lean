import PaperILean.DefinableDistanceBands

/-! I1259: the manuscript's graph-of-distance argument itself. The formula
has a nonnegative value, an attained squared distance, and a universal lower
bound over the complement. QE is an unchanged accepted explicit input. -/

noncomputable section
namespace PaperI
open Set FirstOrder
attribute [local instance] FirstOrder.Ring.compatibleRingOfRing

def planarSquaredDistanceGraph (S : Set (Fin 2 → ℝ)) : Set ((Unit ⊕ Fin 2) → ℝ) :=
  {v | 0 ≤ v (Sum.inl ()) ∧
    (∃ y, y ∉ S ∧ v (Sum.inl ())^2 = planarSquaredDist (fun i => v (Sum.inr i)) y) ∧
    ∀ y, y ∉ S → v (Sum.inl ())^2 ≤ planarSquaredDist (fun i => v (Sum.inr i)) y}

theorem planarSquaredDistanceGraph_definable {S : Set (Fin 2 → ℝ)}
    (hS : (univ : Set ℝ).Definable Language.ring S) :
    (univ : Set ℝ).Definable Language.ring (planarSquaredDistanceGraph S) := by
  let β := Unit ⊕ Fin 2
  let q := planarSquaredDistPolynomial
    (fun i : Fin 2 => Sum.inl (Sum.inr i) : Fin 2 → β ⊕ Fin 2) Sum.inr
  let r : MvPolynomial (β ⊕ Fin 2) ℝ := MvPolynomial.X (Sum.inl (Sum.inl ()))
  have hn := realPolynomial_nonneg_definable (MvPolynomial.X (Sum.inl ()) : MvPolynomial β ℝ)
  have ha := realDefinable_exists ((hS.preimage_comp (Sum.inr : Fin 2 → β ⊕ Fin 2)).compl.inter
    (realPolynomial_zero_definable (r^2-q)))
  have hl := realDefinable_forall ((hS.preimage_comp (Sum.inr : Fin 2 → β ⊕ Fin 2)).union
    (realPolynomial_le_definable (r^2) q))
  convert hn.inter (ha.inter hl) using 1
  ext v
  simp only [planarSquaredDistanceGraph,mem_setOf_eq,mem_inter_iff,mem_union,
    mem_compl_iff,mem_preimage,q,r,planarSquaredDistPolynomial_eval,
    map_sub,map_pow,MvPolynomial.eval_X,Function.comp_def,Sum.elim_inl,Sum.elim_inr,
    sub_eq_zero]
  apply and_congr_right
  intro _
  apply and_congr
  · rfl
  · apply forall_congr'
    intro y
    tauto

def planarDistanceGraph (E : Set (WithLp 2 (Fin 2 → ℝ))) : Set ((Unit ⊕ Fin 2) → ℝ) :=
  {v | v (Sum.inl ()) = Metric.infDist
    ((WithLp.equiv 2 (Fin 2 → ℝ)).symm (fun i => v (Sum.inr i))) Eᶜ}

theorem planarDistanceGraph_eq_squaredDistanceGraph
    {E : Set (WithLp 2 (Fin 2 → ℝ))} (ho : IsOpen E) (hne : Eᶜ.Nonempty) :
    planarDistanceGraph E = planarSquaredDistanceGraph ((WithLp.equiv 2 (Fin 2 → ℝ)) '' E) := by
  ext v
  change (v (Sum.inl ()) = _) ↔ _
  rw [planar_infDist_compl_squared_minimum_iff ho hne]
  have hm (y : Fin 2 → ℝ) : y ∉ (WithLp.equiv 2 (Fin 2 → ℝ)) '' E ↔
      (WithLp.equiv 2 (Fin 2 → ℝ)).symm y ∉ E := by simp
  change (0 ≤ _ ∧ ∃ y, _ ∧ _ ∧ _) ↔ (0 ≤ _ ∧ (∃ y, _) ∧ _)
  simp only [hm]
  constructor
  · rintro ⟨hr,y,hy,he,hl⟩
    exact ⟨hr,⟨y,hy,he⟩,hl⟩
  · rintro ⟨hr,⟨y,hy,he⟩,hl⟩
    exact ⟨hr,y,hy,he,hl⟩

theorem planarDistanceGraph_definable
    {E : Set (WithLp 2 (Fin 2 → ℝ))} (ho : IsOpen E) (hb : Bornology.IsBounded E)
    (hE : (univ : Set ℝ).Definable Language.ring ((WithLp.equiv 2 (Fin 2 → ℝ)) '' E)) :
    (univ : Set ℝ).Definable Language.ring (planarDistanceGraph E) := by
  rw [planarDistanceGraph_eq_squaredDistanceGraph ho (planar_compl_nonempty_of_isBounded hb)]
  exact planarSquaredDistanceGraph_definable hE

theorem published_planarDistanceGraph_has_sign_description
    (hQE : PublishedRealSemialgebraicity)
    {E : Set (WithLp 2 (Fin 2 → ℝ))} (ho : IsOpen E) (hb : Bornology.IsBounded E)
    (hE : HasPolynomialSignDescription ((WithLp.equiv 2 (Fin 2 → ℝ)) '' E)) :
    HasPolynomialSignDescription (planarDistanceGraph E) :=
  hQE.finite_sign_description _
    (planarDistanceGraph_definable ho hb (hasPolynomialSignDescription_definable hE))

end PaperI
