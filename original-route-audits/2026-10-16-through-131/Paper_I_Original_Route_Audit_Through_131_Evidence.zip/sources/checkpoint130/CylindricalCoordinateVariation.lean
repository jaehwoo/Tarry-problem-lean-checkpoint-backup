import PaperILean.CoordinatePathFormat
import PaperILean.CylindricalEndpointOriginalVariation

/-! I1263 coordinate variation using the CAD-constructed endpoint path and
the original analytic/actual derivative-sign subdivision. Hardt is retained
only as a scalar counting/subdivision input. This closes the coordinate
variation step, not graph-arc replacement, tangent/strip geometry or area.
Pre-strategy review: evidence/checkpoint_122_pre_strategy.json. -/

noncomputable section
namespace PaperI
open Set

theorem published_cylindrical_coordinate_path_original_sign_variation
    (hCAD : PublishedCylindricalInitialBandDecomposition)
    (hHardt : PublishedCompatibleSemialgebraicHardtTriviality)
    (hQE : PublishedRealSemialgebraicity)
    (hNash : PublishedOneVariableNashRegularity)
    (hCell : PublishedFiniteConnectedCover)
    (hPiece : PublishedPiecewiseNashExtensions)
    (d : ℕ) (s D : ℕ) :
    ∃ sPath dPath K M : ℕ,
      ∀ (A : Finset (MvPolynomial (Fin d) ℝ)) (S : Set ((Fin d) → ℝ)),
      A.card ≤ s → (∀ q ∈ A, q.totalDegree ≤ D) →
      PolynomialSignDetermined A S → IsPreconnected S →
      Bornology.IsBounded ((WithLp.equiv 2 ((Fin d) → ℝ)).symm '' S) →
      ∀ a ∈ S, ∀ b ∈ S, ∃ γ : SemialgebraicUnitPath S a b,
      ∃ P : Finset (MvPolynomial (Unit ⊕ (Fin d)) ℝ), P.card ≤ sPath ∧
        (∀ q ∈ P, q.totalDegree ≤ dPath) ∧
        PolynomialSignDetermined P (unitPathGraph γ.toFun) ∧
      (∃ C : Finset ℝ, 0 ∈ C ∧ 1 ∈ C ∧ (∀ c ∈ C, c ∈ Icc (0 : ℝ) 1) ∧
        ∀ u ∈ C, ∀ v ∈ C, u < v → (∀ c ∈ C, c ∉ Ioo u v) →
          AnalyticOnNhd ℝ γ.toFun (Ioo u v)) ∧
      ∃ cuts : Finset ℝ, 0 ∈ cuts ∧ 1 ∈ cuts ∧
        (∀ c ∈ cuts, c ∈ Icc (0 : ℝ) 1) ∧ cuts.card ≤ K ∧
        (∀ u ∈ cuts, ∀ v ∈ cuts, u < v → (∀ c ∈ cuts, c ∉ Ioo u v) →
          ∀ i, AnalyticOnNhd ℝ (fun r => γ.toFun r i) (Ioo u v) ∧
            DerivativeSignOn (fun r => γ.toFun r i) (Ioo u v)) ∧
      ∃ (n : ℕ) (t : ℕ → ℝ), n ≤ M ∧ t 0 = 0 ∧ t n = 1 ∧
        MonotoneOn t (Icc 0 n) ∧
        (∀ j < n, ∀ i, MonotoneOn (fun r => γ.toFun r i) (Ioo (t j) (t (j + 1))) ∨
          AntitoneOn (fun r => γ.toFun r i) (Ioo (t j) (t (j + 1)))) ∧
        (∀ i, BoundedVariationOn (fun r => γ.toFun r i) (Icc (0 : ℝ) 1) ∧
          variationOnFromTo (fun r => γ.toFun r i) univ 0 1 ≤
            (M : ℝ) * Metric.diam ((WithLp.equiv 2 ((Fin d) → ℝ)).symm '' S)) ∧
        (∑ i, variationOnFromTo (fun r => γ.toFun r i) univ 0 1) ≤
          (Fintype.card (Fin d) : ℝ) * M * Metric.diam ((WithLp.equiv 2 ((Fin d) → ℝ)).symm '' S) := by
  obtain ⟨sPath, dPath, K, M, h⟩ := published_cylindrical_paths_original_subdivision_variation
    hCAD hHardt hQE hNash hCell hPiece d (Fin d) s D (s + 1) (max D 1)
  refine ⟨sPath, dPath, K, M, ?_⟩
  intro A S hcard hdeg hS hc hbdd a ha b hb
  obtain ⟨γ, P, hPcard, hPdeg, hP, hAnalytic, hvar⟩ :=
    h A S hcard hdeg hS hc a ha b hb
  obtain ⟨cuts, hc0, hc1, hcIcc, hcCard, hcProps, n, t, hn, h0, h1, ht, hm, hv⟩ := hvar (fun i x => x i)
    (fun _ => Metric.diam ((WithLp.equiv 2 ((Fin d) → ℝ)).symm '' S))
    (fun i => (continuous_apply i).continuousOn)
    (coordinate_graph_bounded_sign_format A S s D hcard hdeg hS)
    (coordinate_range_le_euclidean_diameter S hbdd)
  refine ⟨γ, P, hPcard, hPdeg, hP, hAnalytic, cuts, hc0, hc1, hcIcc, hcCard, hcProps,
    n, t, hn, h0, h1, ht, hm, hv, ?_⟩
  calc
    (∑ i, variationOnFromTo (fun r => γ.toFun r i) univ 0 1) ≤
        ∑ _i : (Fin d), (M : ℝ) * Metric.diam ((WithLp.equiv 2 ((Fin d) → ℝ)).symm '' S) :=
      Finset.sum_le_sum (fun i _ => (hv i).2)
    _ = (Fintype.card (Fin d) : ℝ) * M * Metric.diam ((WithLp.equiv 2 ((Fin d) → ℝ)).symm '' S) := by
      simp [mul_assoc]

/-- I1263 with its actual scale L0=max(W0,diam C). The constant is fixed
before every component, coefficient, width and endpoint. This concludes only
the coordinate-variation step, not the subsequent tangent/strip argument. -/
theorem published_cylindrical_planar_component_path_original_sign_variation
    (hCAD : PublishedCylindricalInitialBandDecomposition)
    (hHardt : PublishedCompatibleSemialgebraicHardtTriviality)
    (hQE : PublishedRealSemialgebraicity)
    (hNash : PublishedOneVariableNashRegularity)
    (hCell : PublishedFiniteConnectedCover)
    (hPiece : PublishedPiecewiseNashExtensions) (s D : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ (A : Finset (MvPolynomial (Fin 2) ℝ)) (S : Set (Fin 2 → ℝ)),
      A.card ≤ s → (∀ q ∈ A, q.totalDegree ≤ D) →
      PolynomialSignDetermined A S → IsPreconnected S →
      Bornology.IsBounded ((WithLp.equiv 2 (Fin 2 → ℝ)).symm '' S) →
      ∀ (W0 : ℝ), ∀ a ∈ S, ∀ b ∈ S, ∃ γ : SemialgebraicUnitPath S a b,
        (∀ i, BoundedVariationOn (fun r => γ.toFun r i) (Icc (0 : ℝ) 1)) ∧
        (∑ i, variationOnFromTo (fun r => γ.toFun r i) univ 0 1) ≤
          C * max W0 (Metric.diam ((WithLp.equiv 2 (Fin 2 → ℝ)).symm '' S)) := by
  obtain ⟨sPath, dPath, K, M, h⟩ := published_cylindrical_coordinate_path_original_sign_variation
    hCAD hHardt hQE hNash hCell hPiece 2 s D
  refine ⟨2 * M, by positivity, ?_⟩
  intro A S hcard hdeg hS hc hbdd W0 a ha b hb
  obtain ⟨γ, P, hPcard, hPdeg, hP, hAnalytic, cuts, hc0, hc1, hcIcc, hcCard, hcProps,
    n, t, hn, h0, h1, ht, hm, hv, hsum⟩ :=
    h A S hcard hdeg hS hc hbdd a ha b hb
  refine ⟨γ, fun i => (hv i).1, ?_⟩
  have hsum' : (∑ i, variationOnFromTo (fun r => γ.toFun r i) univ 0 1) ≤
      (2 * M : ℝ) * Metric.diam ((WithLp.equiv 2 (Fin 2 → ℝ)).symm '' S) := by
    simpa using hsum
  exact hsum'.trans (mul_le_mul_of_nonneg_left (le_max_right _ _) (by positivity))

end PaperI

