import PaperILean.PlanarCenterlineFamily

/-! Uniform format of the actual restricted signed-coordinate projection.
The budgets precede coefficients, endpoints, and both coordinate indices.
Only the existing qualitative real-QE contract is used; there is no new
centerline-format premise. This is the format prerequisite at I1263, not
the preparation or strip-area conclusion. -/

noncomputable section
namespace PaperI
open Set FirstOrder
attribute [local instance] Classical.propDecidable Classical.typeDecidableEq
attribute [local instance] FirstOrder.Ring.compatibleRingOfRing
local instance centerlineInputDecidableEq : DecidableEq (Unit ⊕ Fin 2) :=
  Classical.typeDecidableEq _
local instance centerlineOutputDecidableEq : DecidableEq (Fin 2) :=
  Classical.typeDecidableEq _

theorem published_bounded_tuple_centerline_format
    (hQE : PublishedRealSemialgebraicity) (s D : ℕ) :
    ∃ sOut DOut : ℕ, ∀ (P : Fin s → MvPolynomial (Unit ⊕ Fin 2) ℝ),
      (∀ k, (P k).totalDegree ≤ D) →
      ∀ G : Set ((Unit ⊕ Fin 2) → ℝ),
      PolynomialSignDetermined (Finset.univ.image P) G →
      ∀ a b σ : ℝ, ∀ i j : Fin 2,
      ∃ B : Finset (MvPolynomial (Fin 2) ℝ), B.card ≤ sOut ∧
        (∀ q ∈ B, q.totalDegree ≤ DOut) ∧
        PolynomialSignDetermined B (planarCenterlineRelation G a b σ i j) := by
  classical
  let T := (Fin s → Bool × Bool) → Bool
  let J := T × Fin 2 × Fin 2
  let F (k : J) := planarCenterlineFamily
    (universalPolynomialBooleanSet (Unit ⊕ Fin 2) s D k.1) k.2.1 k.2.2
  have hF : ∀ k : J, HasPolynomialSignDescription (F k) := by
    intro k
    apply hQE.finite_sign_description
    exact planarCenterlineFamily_definable (hasPolynomialSignDescription_definable
      (universalPolynomialBooleanSet_hasPolynomialSignDescription
        (Unit ⊕ Fin 2) s D k.1)) k.2.1 k.2.2
  choose sc dc hbudget using fun k : J =>
    hasPolynomialSignDescription_uniform_fiber_sign_format (hF k)
  refine ⟨Finset.univ.sup sc, Finset.univ.sup dc, ?_⟩
  intro P hP G hG a b σ i j
  obtain ⟨table, htable⟩ := polynomialSignDetermined_exists_universal_fiber s D P hP G hG
  let k : J := (table, i, j)
  obtain ⟨B, hcard, hdegree, hB⟩ := hbudget k (polynomialFamilyCoefficients D P)
  let r : Fin 3 → ℝ := ![a,b,σ]
  obtain ⟨C, hCcard, hCdegree, hC⟩ := projectionFiber_has_bounded_sign_format r B
    (projectionFiber (F k) (polynomialFamilyCoefficients D P))
    (sc k) (dc k) hcard hdegree hB
  have hfiber : projectionFiber (projectionFiber (F k) (polynomialFamilyCoefficients D P)) r =
      planarCenterlineRelation G a b σ i j := by
    change projectionFiber (projectionFiber (planarCenterlineFamily _ i j) _) r = _
    rw [planarCenterlineFamily_fiber]
    exact congrArg (fun S => planarCenterlineRelation S a b σ i j) htable.symm
  refine ⟨C, hCcard.trans (Finset.le_sup (f := sc) (Finset.mem_univ k)),
    fun q hq => (hCdegree q hq).trans (Finset.le_sup (f := dc) (Finset.mem_univ k)), ?_⟩
  rwa [hfiber] at hC

theorem published_bounded_centerline_format
    (hQE : PublishedRealSemialgebraicity) (s D : ℕ) :
    ∃ sOut DOut : ℕ, ∀ (A : Finset (MvPolynomial (Unit ⊕ Fin 2) ℝ))
      (G : Set ((Unit ⊕ Fin 2) → ℝ)),
      A.card ≤ s → (∀ q ∈ A, q.totalDegree ≤ D) → PolynomialSignDetermined A G →
      ∀ a b σ : ℝ, ∀ i j : Fin 2,
      ∃ B : Finset (MvPolynomial (Fin 2) ℝ), B.card ≤ sOut ∧
        (∀ q ∈ B, q.totalDegree ≤ DOut) ∧
        PolynomialSignDetermined B (planarCenterlineRelation G a b σ i j) := by
  obtain ⟨sOut, DOut, h⟩ := published_bounded_tuple_centerline_format hQE s D
  refine ⟨sOut, DOut, ?_⟩
  intro A G hcard hdegree hG
  obtain ⟨P, hP, hGP⟩ := exists_bounded_polynomial_tuple_of_signDetermined
    A G s D hcard hdegree hG
  exact h P hP G hGP

theorem published_bounded_actual_centerline_graph_format
    (hQE : PublishedRealSemialgebraicity) (s D : ℕ) :
    ∃ sOut DOut : ℕ, ∀ (A : Finset (MvPolynomial (Unit ⊕ Fin 2) ℝ))
      (γ : ℝ → Fin 2 → ℝ),
      A.card ≤ s → (∀ q ∈ A, q.totalDegree ≤ D) →
      PolynomialSignDetermined A (unitPathGraph γ) →
      ∀ a b σ : ℝ, ∀ i j : Fin 2,
      Icc a b ⊆ Icc (0 : ℝ) 1 →
      MonotoneOn (fun t => σ * γ t i) (Icc a b) →
      ∀ h : ℝ → ℝ, (∀ t ∈ Icc a b, h (σ * γ t i) = γ t j) →
      (∀ q ∈ Icc (σ * γ a i) (σ * γ b i), ∃ t ∈ Icc a b, σ * γ t i = q) →
      ∃ B : Finset (MvPolynomial (Fin 2) ℝ), B.card ≤ sOut ∧
        (∀ q ∈ B, q.totalDegree ≤ DOut) ∧
        PolynomialSignDetermined B
          {v | v 0 ∈ Icc (σ * γ a i) (σ * γ b i) ∧ v 1 = h (v 0)} := by
  obtain ⟨sOut, DOut, hformat⟩ := published_bounded_centerline_format hQE s D
  refine ⟨sOut, DOut, ?_⟩
  intro A γ hcard hdegree hG a b σ i j hunit hm h heq hsurj
  obtain ⟨B, hBcard, hBdegree, hB⟩ := hformat A (unitPathGraph γ)
    hcard hdegree hG a b σ i j
  refine ⟨B, hBcard, hBdegree, ?_⟩
  rwa [planarCenterlineRelation_eq_graph γ a b σ i j hunit hm h heq hsurj] at hB

end PaperI
